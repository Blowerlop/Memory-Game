Memory Game - Rebound CG

Processus de création du jeu:

- Spitch (Déroulement du gameplay)
- 1ère partie du gameplay (Jeu entier / déroulement basique du gameplay --> Création du plateau, carte match, ...)
- 2ème partie du gameplay (Animation)
- Menus
- Création intro avec Unity Timeline (1ère utilisation donc découverte avec prise en main)
- Réglage bug gameplay
- Scoreboard



Soucis rencontré :

- Scoreboard : Problème de synchronisation + essaie de save les datas en interne (première fois que j'essaie, échec, il faudrait que j'essaie à tête reposé sur un projet neuf)

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Card : MonoBehaviour
{
    // Identifiy the data that contain the card
    public CardData cardData;
}
